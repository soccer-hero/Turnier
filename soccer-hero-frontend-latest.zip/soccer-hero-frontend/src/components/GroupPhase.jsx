import React from 'react';

export default function GroupPhase({ tournamentId }) {
  return <div>Gruppenphase für Turnier {tournamentId}</div>;
}
