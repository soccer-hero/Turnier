import React from 'react';

export default function KnockoutPhase({ tournamentId }) {
  return <div>KO-Phase für Turnier {tournamentId}</div>;
}
